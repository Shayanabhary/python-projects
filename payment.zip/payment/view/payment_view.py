from tkinter import *
from tkinter import ttk, messagebox
from tkinter.ttk import Treeview

from controller.payment_controller import PaymentController


# from tkinter import messagebox


class LabelAndTexture:
    # dtype:type[Variable] ==>
    def __init__(self,window,text,x,y,dtype = StringVar, distance=100):
        Label(window, text=text ).place(x=x,y=y)
        self.variable = dtype()
        Entry(window,textvariable=self.variable).place(x=x+distance,y=y)
    def get(self):
        return self.variable.get()
    def set(self, value):
        self.variable.set(value)
    #TODO: این ست و گت دقیقا برای چیه مگه خودمون ورودی نمیدیم؟ دییگه ست و گت برای چیه؟
class PaymentView:
    def __init__(self):
        self.payment_controller=PaymentController()
        self.window = Tk()
        self.window.title("Payment")
        self.window.geometry("1080x500")
        self.window.resizable(False,False)

        self.payment_id = LabelAndTexture(self.window,"Payment ID",40,30)
        self.payment_type = LabelAndTexture(self.window,"Payment Type",40,80)
        self.amount = LabelAndTexture(self.window,"Amount",40,130)
        self.date_time = LabelAndTexture(self.window,"Date Time",40,180)
        self.description = LabelAndTexture(self.window,"Description",40,230)

        # Search fields: each can be used alone or together with the others.
        self.search_id = LabelAndTexture(self.window, "Search ID", 300, 30)
        self.search_type = LabelAndTexture(self.window, "Search Type", 300, 80)
        self.search_amount = LabelAndTexture(self.window, "Search Amount", 300, 130)
        self.search_date = LabelAndTexture(self.window, "Search Date", 300, 180)
        self.search_description = LabelAndTexture(self.window, "Search Description", 300, 230)
        self.search_id.variable.trace_add("write", self.search_click)
        self.search_type.variable.trace_add("write", self.search_click)
        self.search_amount.variable.trace_add("write", self.search_click)
        self.search_date.variable.trace_add("write", self.search_click)
        self.search_description.variable.trace_add("write", self.search_click)

        Button(self.window, text="Search", width=18, command=self.search_click).place(x=380, y=280)
        Button(self.window, text="Save",width=7,command=self.save_click).place(x=30,y=400)
        Button(self.window, text="Edit",width=7,command=self.edit_click).place(x=100,y=400)
        Button(self.window, text="Delete",width=7,command=self.delete_click).place(x=170,y=400)
        Button(self.window , text="Reset",width=27,command=self.reset_click).place(x=31,y=370) #TODO : COMPLETE THIS
        self.table = Treeview(self.window, columns=[1,2,3,4,5],show="headings",height=18)
        self.table.column(1, width=100)
        self.table.column(2, width=100)
        self.table.column(3, width=100)
        self.table.column(4, width=100)
        self.table.column(5, width=100)
        self.table.heading(1, text="Payment ID")
        self.table.heading(2, text="Payment Type")
        self.table.heading(3, text="Amount")
        self.table.heading(4, text="Date Time")
        self.table.heading(5, text="Description")
        self.table.place(x=550, y=20)
        self.reset_click()
        self.table.bind("<<TreeviewSelect>>", self.select_payment)




        self.window.mainloop()

    def show_data_on_table(self,payment_list):
        for row in self.table.get_children():
            self.table.delete(row)
        for payment in payment_list:
            self.table.insert("", "end",values=payment.to_tuple())
    def save_click(self):
       status , message = self.payment_controller.save(
           self.payment_id.get(),
           self.payment_type.get(),
           self.amount.get(),
           self.date_time.get(),
           self.description.get(),
       )
       if status :
           messagebox.showinfo("Payment Added Successfully", message)
           self.reset_click()
       else:
           messagebox.showerror("Error Saving Payment!!!!", message)

    def edit_click(self):
        status, message = self.payment_controller.edit(
            self.payment_id.get(),
            self.payment_type.get(),
            self.amount.get(),
            self.date_time.get(),
            self.description.get(),
        )
        if status:
            messagebox.showinfo("Payment Edited Successfully", message)
            self.reset_click()
        else:
            messagebox.showerror("Payment Has Not Been Edited!!!!", message)

    def delete_click(self):

        if messagebox.askyesno("Delete Payment", "Are you sure you want to delete this payment?"):
            status, message = self.payment_controller.delete(
            self.payment_id.get())
            if status:
                messagebox.showinfo("Payment Removed Successfully", message)
                self.reset_click()
            else:
                messagebox.showerror("Payment Has Not Been Removed!!!!", message)

    def reset_click(self):
        self.payment_id.set("")
        self.payment_type.set("Cash")
        self.amount.set("")
        self.description.set("")
        self.date_time.set("")
        self.search_id.set("")
        self.search_type.set("")
        self.search_amount.set("")
        self.search_date.set("")
        self.search_description.set("")
        # همیشه از همان کنترلری استفاده کن که Save/Edit/Delete با آن انجام می‌شود.
        status , result = self.payment_controller.find_all()
        if status:
            self.show_data_on_table(result)
        else:
            messagebox.showerror("Error","No payment found!!")

    def search_click(self, *args):
        """Filter the table by any filled search field."""
        payment_id = self.search_id.get().strip()
        payment_type = self.search_type.get().strip().lower()
        amount = self.search_amount.get().strip()
        date_time = self.search_date.get().strip().lower()
        description = self.search_description.get().strip().lower()

        status, payments = self.payment_controller.find_all()
        if not status:
            messagebox.showerror("Error", "Payments could not be loaded")
            return

        result = [
            payment for payment in payments
            if (not payment_id or str(payment.payment_id).startswith(payment_id))
            and (not payment_type or payment_type in payment.payment_type.lower())
            and (not amount or str(payment.amount).startswith(amount))
            and (not date_time or date_time in str(payment.date_time).lower())
            and (not description or description in payment.description.lower())
        ]
        self.show_data_on_table(result)

        if not result and any((payment_id, payment_type, amount, date_time, description)):
            messagebox.showinfo("Search", "No matching payment was found.")

    def select_payment(self,event):
        row_id =self.table.focus()
        selected_row = self.table.item(row_id )["values"]
        if selected_row:
            self.payment_id.set(selected_row[0])
            self.payment_type.set(selected_row[1])
            self.amount.set(selected_row[2])
            self.date_time.set(selected_row[3])
            self.description.set(selected_row[4])
        #todo : selected_row = self.table.item(row_id ,["values"] ) اون option ولیوز دقیقا جیه؟

# TODO : grid pack?

#TODO : یک عدد لیبل خالی برای کامبوباکس PAYMENT TYPE

