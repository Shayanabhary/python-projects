from model.bl.payment_bl import PaymentBl
from model.entity.payment import Payment
from datetime import datetime



class PaymentController :
    def __init__(self):
        self.bl = PaymentBl()

    def save(self,payment_id, payment_type, amount, date_time, description):
        try:
            payment = self._make_payment(payment_id, payment_type, amount, date_time, description)
            self.bl.save(payment)
            return True,"Payment Saved"
        except Exception as e:
            return False,f"Error while saving payment: {e}"
    def edit(self,payment_id, payment_type, amount, date_time, description):
        try:
            payment = self._make_payment(payment_id, payment_type, amount, date_time, description)
            self.bl.edit(payment)
            return True,"Payment Edited"
        except Exception as e:
            return False,f"Error while editing payment: {e}"

    def delete(self, payment_id):
        try:
            self.bl.delete(int(payment_id))
            return True,"Payment deleted successfully"
        except Exception as e:
            return False,f"Error while deleting payment: {e}"
    def find_all(self):
        try:
            return True, self.bl.find_all()
        except Exception as e:
            return False,f"Error while finding all payments: {e}"

    def find_by_id(self,payment_id):
        try:
            return True, self.bl.find_by_id(payment_id)
        except Exception as e:
            return False,f"Error while finding payment: {e}"

    def find_by_payment_type(self,payment_type):
        try:
            return self.bl.find_by_payment_type(payment_type)
        except Exception as e:
            return False,f"Error while finding payment type: {e}"
    def find_by_amount(self,payment_amount):
        try:
            return self.bl.find_by_amount(payment_amount)
        except Exception as e:
            return False,f"Error while finding payment by amount: {e}"

    @staticmethod
    def _make_payment(payment_id, payment_type, amount, date_time, description):
        """Convert Tkinter's text inputs to the types required by Payment."""
        date_text = str(date_time).strip()
        parsed_date = None
        for date_format in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
            try:
                parsed_date = datetime.strptime(date_text, date_format)
                break
            except ValueError:
                continue
        if parsed_date is None:
            raise ValueError("Date Time must be YYYY-MM-DD or YYYY-MM-DD HH:MM")

        return Payment(
            int(payment_id),
            str(payment_type).strip(),
            int(amount),
            parsed_date,
            str(description).strip(),
        )
