import re
from datetime import datetime

class Payment:
    def __init__(self, payment_id, payment_type, amount, date_time, description):
        self.payment_id = payment_id
        self.payment_type = payment_type
        self.amount = amount
        self.date_time = date_time
        self.description = description

    @property
    def payment_id(self):
        return self.__payment_id

    @payment_id.setter
    def payment_id(self, value):
        if type(value) != int:
            raise ValueError("Payment id must be of type int")
        self.__payment_id = value

    @property
    def payment_type(self):
        return self.__payment_type

    @payment_type.setter
    def payment_type(self, value):
        self.__payment_type = value

    @property
    def amount(self):
        return self.__amount

    @amount.setter
    def amount(self, value):
        if type(value) != int or value <0:
            raise ValueError("Amount must be of type int")
        self.__amount = value

    @property
    def date_time(self):
        return self.__date_time

    @date_time.setter
    def date_time(self, value):
        if type(value) != datetime:
            raise ValueError("Date time must be of type datetime")
        self.__date_time = value

    @property
    def description(self):
        return self.__description

    @description.setter
    def description(self, value):
        if type(value) != str or not re.fullmatch(r".{1,200}", value.strip(), re.DOTALL):
            raise ValueError("Description must be a text between 1 and 200 characters")
        self.__description = value

    def __repr__(self):
        return f"{self.__payment_id}, {self.payment_type}, {self.amount}, {self.date_time}, {self.description}"

    def to_tuple(self):
        return tuple((self.payment_id, self.payment_type, self.amount, self.date_time, self.description))
