import pickle
from pathlib import Path

from model.entity.payment import Payment

payment_list=[]
class PaymentDa:
    def __init__(self):
        # مستقل از پوشه‌ای که برنامه از آن اجرا می‌شود.
        self.file_path = Path(__file__).with_name("payment_da")
        if self.file_path.exists():
            with open(self.file_path, "rb") as self.file:
                self.payment_list = pickle.load(self.file)
        else:
            self.payment_list= []
            self.file = None

    def save(self, payment):
        with open(self.file_path, "wb") as self.file:
            self.payment_list.append(payment)
            pickle.dump(self.payment_list,self.file)

    def edit(self, payment):
        with open(self.file_path, "wb") as self.file:
            self.payment_list = list(filter(lambda pay: pay.payment_id != payment.payment_id, self.payment_list))
            self.payment_list.append(payment)
            pickle.dump(self.payment_list,self.file)

    def remove_by_id(self, payment_id):
        with open(self.file_path, "wb") as self.file:
            self.payment_list = list(filter(lambda pay: pay.payment_id != payment_id,self.payment_list))
            pickle.dump(self.payment_list,self.file)

    def find_all(self):
        return sorted(self.payment_list, key=lambda pay: pay.payment_id)

    def find_by_id(self, payment_id):
        found_payment = list(filter(lambda pay: pay.payment_id == payment_id, self.payment_list))
        if found_payment:
            return found_payment[0]
        else:
            return None

    def find_by_payment_type(self, pay_type):
        found_payment = list(filter(lambda pay: pay.payment_type == pay_type, self.payment_list))
        if found_payment:
            return found_payment[0]
        else:
            return None

    def find_by_amount(self, pay_amount):
        found_payment = list(filter(lambda pay: pay.amount == pay_amount, self.payment_list))
        if found_payment:
            return found_payment[0]
        else:
            return None

    #todo: add startswith search
