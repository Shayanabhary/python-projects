from model.da.payment_da import *
from model.entity import payment


class PaymentBl :
    def __init__(self):
        self.da = PaymentDa()

    def save(self,payment):
        if self.da.find_by_id(payment.payment_id) :
            raise ValueError("Payment id already exists!!!")
        # else:
        self.da.save(payment)

    def edit(self,payment):
        if not self.da.find_by_id(payment.payment_id) :
            raise ValueError("Payment id doesn't exist!!!")
#         else:  TODO:جرا نباید الس بذاریم؟
        self.da.edit(payment)

    def delete(self,payment_id):
        if not self.da.find_by_id(payment_id) :
            raise ValueError("Payment id doesn't exist!!!")
#         else:
        self.da.remove_by_id(payment_id)

    def find_all(self):
        return self.da.find_all()

    def find_by_id(self,payment_id):
        return self.da.find_by_id(payment_id)

    def find_by_payment_type(self,payment_type):
        return self.da.find_by_payment_type(payment_type)

    def find_by_amount(self,payment_amount):
        return self.da.find_by_amount(payment_amount)
    #TODO : ارور ها و پیامارو بنویسم