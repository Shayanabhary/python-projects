from os import remove

from controller.payment_controller import PaymentController
from model.entity.payment import Payment
from datetime import datetime
from model.da.payment_da import PaymentDa

# payment = Payment(1,"cash",1234,datetime(2023,11,2,20,8,0),"tozih")
# print(payment)

payment_controller = PaymentController()

# test passed
# payment_da.save(payment)
# payment_da.edit(payment)




# payment2 = Payment(2,"cash",2222,datetime(2022,11,2,20,8,0),"tozih")
# payment3 = Payment(3,"card",3333,datetime(2023,11,2,20,8,0),"tozih")
# payment4 = Payment(4,"card",4444,datetime(2024,11,2,20,8,0),"tozih")
# payment5 = Payment(5,"card",5555,datetime(2025,11,2,20,8,0),"tozih")
# payment6 = Payment(6,"card",6666,datetime(2006,11,2,20,8,0),"tozih")

# payment_controller.save(2,"cash",2222,datetime(2022,11,2,20,8,0),"tozih")
# payment_controller.save(3,"card",3333,datetime(2023,11,2,20,8,0),"tozih")
# payment_controller.save(4,"card",4444,datetime(2024,11,2,20,8,0),"tozih")
# payment_controller.save(5,"card",5555,datetime(2025,11,2,20,8,0),"tozih")
# payment_controller.save(6,"card",6666,datetime(2006,11,2,20,8,0),"tozih")
#
# # test passed
# print(payment_controller.find_all())


# todo : تست تمام موارد انجام شود
# from controller.payment_controller import PaymentController
#
# pay_controller = PaymentController()
# pay_controller.save(7,"check",2222,datetime(2022,11,2,20,8,0),"tozih")
# status , message = pay_controller.save(3,"cash", 1000 , datetime(2022,11,2,20,8,0),"tozihat")

# print(status)
# print(message)
# print(payment_controller.find_all())
# result2 ,message = pay_controller.find_all()
# print(result2)
# print(message)